from Board import Board
from Config import *
from Craig import *

import random 
import time

import pygame
pygame.init()

screen = pygame.display.set_mode((480, 480))
pygame.display.set_caption('Your turn')

def tileClicked(pos):
    # 1.create a for loop with the variable row and is in range of 8
        #2.create a for loop with the variable column and is in range of 8
            if pygame.Rect(column * 60, row * 60, 60, 60).collidepoint(pos):
                return(row, column)

        #3.return the variable None


#4.set whitesTurn equal to true 
#5.set selected equals to None
moves = []

#6.set board equals to Board()

#7.set playing equals to True
#8.create a while loop with a variable known as playing

    if not whitesTurn:  # Craig's turn
        startTime = time.time()

        pygame.display.set_caption('Craig\'s move')
        #9. set move equals to a functuion known as getNextMove that holds two parameters(board and DEPTH) and is seperated by a comma
        board.makeMove(move) 
        
        #10. set  endTime equals to time.time()
        print('\n\nCraig took %.1f seconds to compute his move'%(endTime - startTime))
        print('(r%g, c%g) to (r%g, c%g)'%(move[0][0], move[0][1], move[1][0], move[1][1]))
        print('Board = %.2f'%board.evaluate(True))

        selected = None
        #11.set moves equal to an empty array/list
        #12.set whitesTurn equals to True
        pygame.display.set_caption('Your move')
        #13.add the continute statemnet

    for event in pygame.event.get():
        #14. create an if statement that event.type equals equals to pygame.QUIT
            pygame.quit()
            #15. set playing equals to False

        elif event.type == pygame.MOUSEBUTTONDOWN and not board.isGameOver():
            #16.set pos equal to pygame.mouse.get_pos()
            #17.set clickedPos equal to a function known as tileClicked nad holds one parameter

            if board()[clickedPos[0]][clickedPos[1]] != None and board()[clickedPos[0]][clickedPos[1]].white == whitesTurn and clickedPos != selected:
                selected = (clickedPos[0], clickedPos[1])
                 #18.set moves equals to board()[selected[0]][selected[1]].getMoves(board())

            elif selected != None and (selected, clickedPos) in moves:
                board.makeMove((selected, clickedPos))                    
                
                # 19.set whitesTurn equal to not whitesTurn
                selected = None
                moves = []

            else:
               # 20.set selected equal to none
                moves = []
    
    board.drawBoard(selected, moves, screen)
