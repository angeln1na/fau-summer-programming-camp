class Colors:
    def red(): return (235, 107, 84)
    def yellow(): return (235, 227, 84)
    def green(): return (84, 235, 94)
    def blue(): return (84, 152, 235)
    def dicebutton(): return (48, 219, 216)
    def dicebuttonpressed(): return (14, 87, 85)
    def passbutton(): return (52, 110, 235)
    def passbuttonpressed(): return (41, 74, 143)