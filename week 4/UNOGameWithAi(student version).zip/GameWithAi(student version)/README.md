# GameWithAi
The Game UNO! written in Python with an AI to play against (hardcoded :c) 

### How to Play

You have cards in your Handy, you need to match the cards in your Handy with the cards on the Stack. 
Card             |  Desciption
:-:|:-
![Card](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/Blue/Cards.png) | This Card adds two more Cards to the ai's hand
![Block](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/Blue/Blocked.png) | This Card let you play another move after playing this card
![Reverse](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/Blue/Reverse.png) | This Card is not used in this game cause it wouldn't change anything
![Wild](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/More/Wild.png) | This card let you choose a color
![Wild4](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/More/Wild+4.png) | This card let you choose a color and give four cards to ai's hand

Button | Desciption
:-:|:-
![Pickup](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/buttons/PickUp.png) | This Button gives you a new card on your hand in case you cant do anything
![Pickup](https://raw.githubusercontent.com/flloschy/GameWithAi/master/v2/Textures/buttons/UnoButton.png) | You need to Press this Button when you have only one card left, when not and you play the last card, your hand gets 2 more cards
