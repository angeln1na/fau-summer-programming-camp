# Tic-Tac-Toe
> ![Tic-tac-toe](https://media.giphy.com/media/KGx1mnE84JAWHxtUlL/giphy.gif)
# How can I run it?
```
Clone the repository.
```
```python
pip install pygame
```
```python
python game.py
```
# Version 2
* Improved mechanics
* Added sound effects and music
* Reduced input lag
* Better and more enjoyable game design
# Description

---

> Hey guys, so I decided to post my first pygame project here and try to improve by practicing more and helping others!
Please if you like it, give me some feedback :) 
Also I really appreciate people who try to fix erros/bugs or simply make the program more readable and more enjoyable..
Thank youu for reading this!!

---

> [![forthebadge](https://forthebadge.com/images/badges/made-with-python.svg)](https://github.com/debugleader/Tic-Tac-Toe)

---
